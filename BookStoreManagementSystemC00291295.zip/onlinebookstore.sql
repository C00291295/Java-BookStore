-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 30, 2024 at 10:49 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinebookstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
CREATE TABLE IF NOT EXISTS `book` (
  `BookID` int NOT NULL AUTO_INCREMENT,
  `BookName` varchar(255) DEFAULT NULL,
  `BookDescription` varchar(2000) DEFAULT NULL,
  `BookPrice` double DEFAULT NULL,
  `publisher_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`BookID`),
  KEY `fk_publisher_name` (`publisher_name`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`BookID`, `BookName`, `BookDescription`, `BookPrice`, `publisher_name`) VALUES
(1, 'Hamlet', 'Among Shakespeare\'s plays, \"Hamlet\" is considered by many his masterpiece. Among actors, the role of Hamlet, Prince of Denmark, is considered the jewel in the crown of a triumphant theatrical career. Now Kenneth Branagh plays the leading role and co-directs a brillant ensemble performance. Three generations of legendary leading actors, many of whom first assembled for the Oscar-winning film \"Henry V\", gather here to perform the rarely heard complete version of the play. This clear, subtly nuanced, stunning dramatization, presented by The Renaissance Theatre Company in association with \"Bbc\" Broadcasting, features such luminaries as Sir John Gielgud, Derek Jacobi, Emma Thompson and Christopher Ravenscroft. It combines a full cast with stirring music and sound effects to bring this magnificent Shakespearen classic vividly to life. Revealing new riches with each listening, this production of \"Hamlet\" is an invaluable aid for students, teachers and all true lovers of Shakespeare - a recording to be treasured for decades to come.\r\n', 10, 'Anvil Press Poetry'),
(2, 'TestBook2', 'Testing for Table', 11, 'Testing'),
(4, 'The Fallout Saga: A Tale of Mutation, Creation, Universe, Decryption\r\n', 'Immerse yourself in the world of Fallout by exposing what this saga represents, what she wanted to tell us over the titles; to present the major steps taken by the series, the changes it has undergone: this is what the book that you hold in your hands - including to understand the links of love and hatred that Fallout maintains today with his audience. Before formulating analyzes and theories, however, this book will lay a solid foundation by tracing more fundamentally the genesis of each games.	', 10, 'Third Editions'),
(7, 'Unicorn', 'A Book About a unicorn	', 10, 'Fairytale limited '),
(10, 'Art Of Fallout 4 HC ', 'The Art Of Fallout 4 is a must-have collectible for fans and a trusty companion for every Wasteland wanderer', 11, 'Test');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `first_name`, `last_name`, `email`, `phone_number`, `address`) VALUES
(1, 'Justus', 'Leong', 'JustusLeong@gmail.com', '0127192284', 'CarlowStreet'),
(3, 'Edison', 'James', 'Edison@gmail.com', '0127192284', 'Carlow Street'),
(4, 'Rishi', 'Ray', 'Rishi@gmail.com', '0127192284', 'Dublin Street');

-- --------------------------------------------------------

--
-- Table structure for table `ordert`
--

DROP TABLE IF EXISTS `ordert`;
CREATE TABLE IF NOT EXISTS `ordert` (
  `OrderID` int NOT NULL AUTO_INCREMENT,
  `OrderDate` date DEFAULT NULL,
  `TotalAmount` double DEFAULT NULL,
  `DeliveryOption` varchar(55) DEFAULT NULL,
  `CustomerID` int DEFAULT NULL,
  `BookID` int DEFAULT NULL,
  `OrderQuantity` int DEFAULT NULL,
  PRIMARY KEY (`OrderID`),
  KEY `FK_Customer_Ordert` (`CustomerID`),
  KEY `FK_Book_Ordert` (`BookID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `ordert`
--

INSERT INTO `ordert` (`OrderID`, `OrderDate`, `TotalAmount`, `DeliveryOption`, `CustomerID`, `BookID`, `OrderQuantity`) VALUES
(1, '2024-12-22', 10, 'Normal', 1, 1, 1),
(5, '2024-04-09', 10, 'Express', 3, 1, 2),
(3, '2024-04-04', 10, 'Express', 1, 1, 1),
(4, '2024-04-10', 10, 'Express', 3, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `publisher`
--

DROP TABLE IF EXISTS `publisher`;
CREATE TABLE IF NOT EXISTS `publisher` (
  `publisher_id` int NOT NULL AUTO_INCREMENT,
  `publisher_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `contact_person` varchar(50) DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`publisher_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `publisher`
--

INSERT INTO `publisher` (`publisher_id`, `publisher_name`, `contact_person`, `email`, `phone_number`, `address`) VALUES
(1, 'Anvil Press Poetry', 'William ', 'William@gmail.com', '0127192284', 'Carlow street'),
(4, 'Unicorn Limited', 'Mr Wonka', 'Unicornlimited@gmail.com', '0127292284', 'Dublin Kilkennys Street'),
(3, 'Third Editions', 'Mehdi El Kanafi', 'ThirdEditions@gmail.com', '0127192234', 'Carlow street ');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
CREATE TABLE IF NOT EXISTS `stock` (
  `StockID` int NOT NULL AUTO_INCREMENT,
  `Quantity` int NOT NULL,
  `BookID` int DEFAULT NULL,
  PRIMARY KEY (`StockID`),
  KEY `FK_Book_Stock` (`BookID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`StockID`, `Quantity`, `BookID`) VALUES
(1, 17, 1),
(2, 10, 2),
(3, 20, 3);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `userid` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `username`, `password`) VALUES
(1, 'User', 'User1234'),
(2, 'Justus', 'Justus1469'),
(3, 'Edison', 'Edison1469'),
(4, 'Chang', 'Chang1469');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
