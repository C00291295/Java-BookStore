package bookstoremanagementsystem;


public class BookStoreManagementSystem {

    
    public static void main(String[] args) {
        LoginPage loginPage = new LoginPage();
        
       
        loginPage.setVisible(true);
    }
        
  
    
}
